import { useEffect } from "react";

export default function Notification({ message, onChangerMessage }) {
  useEffect(() => {
    if (!message) return;
    setTimeout(() => onChangerMessage(""), 3000);
  }, []);

  if (!message) return null;
  return (
    <div role="status" className="notification">
      {message}
    </div>
  );
}
