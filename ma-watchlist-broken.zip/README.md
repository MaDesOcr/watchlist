# Ma Watchlist : version cassée

Cette application contient **12 bugs**. À vous de les trouver et de les corriger.

```bash
npm install
npm run dev      # lancer l'application
npm test         # les tests en rouge vous guident
npm run lint     # l'analyseur trouve certains bugs à votre place
```

Notez chaque bug corrigé dans `BUGS.md`.
