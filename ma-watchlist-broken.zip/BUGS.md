# Journal des bugs

| # | Symptôme observé | Fichier | Cause | Correction | Notion React |
|---|---|---|---|---|---|
| 1 |  |  |  |  |  |
